// FILL IN THESE REQUIRED VARS
const APIKEY = "";
const CLIENTID = "";
const NETVALVE_MID_ID = "";
const THREEDS_PROVIDER= 'RYVYL' // 'CARDINAL'

// URLS
const SANDBOX_3DSECURE_URL = "https://3dsecuresuite.uat.sandbox-netvalve.com";
const PAYMENT_API_URL = "https://payment-api.uat.sandbox-netvalve.com";

// CARD NUMBER
const SUCCESS_CARDINAL_CARD_NUMBER = "4000000000001091"; 
const SUCCESS_RYVYL_CARD_NUMBER = "4100000000005000";
// The card number must match the card number used in the 3DS flow
const CARD_NUMBER =  THREEDS_PROVIDER === 'RYVYL' ? SUCCESS_RYVYL_CARD_NUMBER : SUCCESS_CARDINAL_CARD_NUMBER; 

document.addEventListener("DOMContentLoaded", () => {
    const message = document.getElementById("message");

    const transactionId = getQueryParam("transID");

    if (!APIKEY || !CLIENTID || !NETVALVE_MID_ID || !PAYMENT_API_URL) {
        message.innerHTML = "Missing required variables";
        return;
    }

    if (!transactionId) {
        message.innerHTML = "No transaction ID found";
        return;
    }

    fetchResult(transactionId);


    // Function to execute a fetch request using the transID
    async function fetchResult(transID) { 
        try {
            // Body
            const pkg = {
                netvalveMidId: NETVALVE_MID_ID,
                transID,
            };

            const response = await fetch(`${PAYMENT_API_URL}/3ds/result `, {
                method: "POST",
                headers: {
                    // Authorization: `Basic ${basicAuthCredentials}`,
                    "Netvalve-Api-Key": APIKEY,
                    "Netvalve-Client-Id": CLIENTID,
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(pkg),
            });

            const data = await response.json();

            console.log('----- FETCH 3DS RESULT -----');
            console.log(data);

            if (data.responseCode !== "3DS_1000" && data.responseCode !== "3DS_1001") {
                throw new Error();
            }

            performSale(data);

        } catch (error) {
            // Display error message
            message.innerHTML = "The 3DS flow completed, but an error occurred using its transId to fetch the result";
        }
    }

    async function performSale(resp) {
        const threeDsVals = mapThreeDsVals(resp);
        threeDsVals.version = "2.1.0";

        const salePayload = {
            netvalveMidId: NETVALVE_MID_ID,
            amount: 43.1,
            currency: "USD",
            cardExpireMonth: "08",
            cardExpireYear: "2025",
            cardHolderName: "Yogesh",
            cardNumber: CARD_NUMBER,
            cardSecurityCode: "123",
            clientOrderId: Math.floor(Math.random() * 10000), // Unique client order Id
            customerLastName: "Test",
            customerName: "Test",
            "3DS": threeDsVals, // The attached 3DS Vals
        };

        const response = await fetch(`${PAYMENT_API_URL}/sale `, {
            method: "POST",
            headers: {
                // Authorization: `Basic ${basicAuthCredentials}`,
                "Netvalve-Api-Key": APIKEY,
                "Netvalve-Client-Id": CLIENTID,
                "Content-Type": "application/json",
            },
            body: JSON.stringify(salePayload),
        });

        const result = await response.json();

        console.log('----- SALE WITH 3DS RESULT -----');
        console.log(result);

        if (result.responseCode === "GTW_1000" || result.responseCode === "GTW_1001") // Demo implementation. Check the success response code statuses 
            message.innerHTML = "<span style='color: green'>Successful payment! </span><small style='display: block; font-size: 12px; padding: 10px'>The 3ds values were sent to the sale api, and the sale transaction was successful. </small>";
        else {
            message.innerHTML = "<span style='color: green'>The 3DS flow completed.</span><span style='color: red'>The Sale Transaction Failed.</span><small style='display: block; font-size: 12px; padding: 10px'>The result was logged to the console"
        };
    }

    function mapThreeDsVals(response) {
        const eci = response.threeDSProviderResponse.eci;
        const cavv = response.threeDSProviderResponse.cavv;
        const dsTransactionId = response.threeDSProviderResponse.threeDs2TransactionId;
        const version = response.threeDSProviderResponse.threeDsVersion;
        const threeDsVals = { dsTransactionId, eci, cavv, version };
        return threeDsVals;
    }

    // Function to extract query parameters from a URL
    function getQueryParam(key) {
        const queryParams = {};
        const urlObject = new URL(window.location.href);
        urlObject.searchParams.forEach((value, key) => {
            queryParams[key] = value;
        });
        return queryParams[key];
    }
});
