// FILL IN THESE REQUIRED VARS    
const APIKEY = "";
const CLIENTID = "";
const NETVALVE_MID_ID = "";

// SELECT THE 3DS PROVIDER
const THREEDS_PROVIDER= 'RYVYL' // 'CARDINAL'

// URLS
const SANDBOX_3DSECURE_URL = "https://3dsecuresuite.uat.sandbox-netvalve.com";
const PAYMENT_API_URL = "https://payment-api.uat.sandbox-netvalve.com";
const MERCHANT_REDIRECT_URL = window.location.origin + "/result.html";

// CARD NUMBER
const SUCCESS_CARDINAL_CARD_NUMBER = "4000000000001091"; // challenge card
const SUCCESS_RYVYL_CARD_NUMBER = "4100000000005000"; // challenge card
const CARD_NUMBER =  THREEDS_PROVIDER === 'RYVYL' ? SUCCESS_RYVYL_CARD_NUMBER : SUCCESS_CARDINAL_CARD_NUMBER; 


document.addEventListener("DOMContentLoaded", function () {
    const buyButton = document.getElementById("buy-button");
    const orderModal = document.getElementById("order-modal");
    const closeButton = document.querySelector(".close-button");
    const modalContent = document.querySelector(".modal-content");


    // User clicks BUY
    buyButton.addEventListener("click", async (e) => {
        open3DsModal(e);

        // START 3DS Flow
        const response = await initialize(); 
        if (response.responseCode !== '3DS_1000' && response.responseCode !== '3DS_1001') return showError(response);
        else if (response.threeDSProviderResponse.eci && response.threeDSProviderResponse.cavv) // Flow A - 3DS complete
            sale(response.threeDSProviderResponse);
        else if (response.threeDSProviderResponse.status === 'ACS_REQUIRED') // Flow B - challenge required
            redirectToChallengePage(response);
        else if (response.threeDSProviderResponse.status === 'INITIALIZED') // Flow C - device data collection required
            deviceDataCollection(response); 
    });

    async function initialize() { // this should be called on the server
        try {

            const browserData = fetchBrowserData()

            // Body
            const requestBody = {
                netvalveMidId: NETVALVE_MID_ID,
                merchantRedirectUrl: MERCHANT_REDIRECT_URL,
                amount: 43.1,
                currency: "USD",
                cardExpireMonth: "08",
                cardExpireYear: "2025",
                cardHolderName: "Yogesh",
                cardNumber: CARD_NUMBER,
                customerEmail: "yogesh@dahe.com", // for visa 3ds
                customerPhone: "+919900000000", // for visa 3ds
                customerIp: '123.123.123.123', 
                ...browserData
            };

            const response = await fetch(`${PAYMENT_API_URL}/3ds/v2/initialization`, {
                method: "POST",
                headers: {
                    // Authorization: `Basic ${basicAuthCredentials}`,
                    "Netvalve-Api-Key": APIKEY,
                    "Netvalve-Client-Id": CLIENTID,
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(requestBody),
            });

            const data = await response.json();
            return data;
        } catch (error) {
            console.log(error)
        }
    }

    function deviceDataCollection(initResponse) {

        console.log('INSIDE DEVICE DATA COLLECTION')
        const redirectUrl = initResponse.threeDSProviderResponse.redirectUrl; // extract the redirect URL

        // Insert hidden iframe with src set to redirectUrl
        const iframe = document.createElement("iframe");
        iframe.style.display = "none";
        iframe.src = redirectUrl;
        modalContent.appendChild(iframe);
    }

    // Be sure to attach the listener for the iframe POST MESSAGE event
    window.addEventListener("message", handlePostEvent, false);

    async function authenticate(postMessage) { // this should be called on the server
        const transID = postMessage.threeDsResponse.transID; // Extract the transID
        try {
            // Body
            const requestBody = {
                netvalveMidId: NETVALVE_MID_ID,
                amount: 43.1,
                currency: "USD",
                cardExpireMonth: "08",
                cardExpireYear: "2025",
                cardHolderName: "Yogesh",
                cardNumber: CARD_NUMBER,
                customerLastName: "Test",
                customerName: "Test",
                customerEmail: "yogesh@dahe.com", 
                customerPhone: "+919900000000", 
                customerIp: '123.123.123.123', 
                transID, // This is the transaction ID we need to add in
            };

            const response = await fetch(`${PAYMENT_API_URL}/3ds/authentication`, {
                method: "POST",
                headers: {
                    // Authorization: `Basic ${basicAuthCredentials}`,
                    "Netvalve-Api-Key": APIKEY,
                    "Netvalve-Client-Id": CLIENTID,
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(requestBody),
            });

            const data = await response.json();
            return data;
        } catch (error) {
            console.log(error)
        }
    }

    function redirectToChallengePage(response){
        window.location.href = response.threeDSProviderResponse.redirectUrl;
    }

    function sale(response){
        // For demo purposes, it will redirect to a Result page, where the sale API will be called
        window.location.href = `/result.html?transID=${response.threeDSProviderResponse.transID}`;
    }


    async function handlePostEvent (event) {
        if (event.origin === SANDBOX_3DSECURE_URL) {
            const data = event.data;
            console.log('INSIDE HANDLE POST EVENT')
            if (data.result === 'ERROR') return showError(data);
            const response = await authenticate(data);
            if (!response || (response.responseCode !== '3DS_1000' && response.responseCode !== '3DS_1001')) showError(response);
            if (response.threeDSProviderResponse.eci && response.threeDSProviderResponse.cavv)
                sale(response.threeDSProviderResponse);
            else if (response.threeDSProviderResponse.status === 'ACS_REQUIRED')
                redirectToChallengePage(response);
        }
    };


    // Modal
    closeButton.addEventListener("click", function () {
        orderModal.style.display = "none";
    });

    window.addEventListener("click", function (event) {
        if (event.target == orderModal) {
            orderModal.style.display = "none";
        }
    });

    function fetchBrowserData(){
        return {
            userAgent: navigator.userAgent,
            browserHeader: 'text/html,application/xhtml+xml,application/xml;q=0.9,/;q=0.8',
            browserJavaEnabled: navigator?.javaEnabled() || false,
            browserLanguage: navigator?.language || navigator?.userLanguage,
            browserColorDepth: screen.colorDepth,
            browserScreenHeight: screen.height,
            browserScreenWidth: screen.width,
            browserTimeZone: new Date().getTimezoneOffset()
        };
    }

    function open3DsModal(e){
        e.preventDefault();
        orderModal.style.display = "block";
        showSpinner();
    }
    
    function showError(data) {
        console.log(data)
        modalContent.innerHTML = `<p>An error has occurred, check the console.</p>`;
    }

    function showSpinner() {
        modalContent.innerHTML =
            '<div class="loader-container"><div class="loader"></div><p>Please wait to be redirected</p></div>';
    }
});
